    
/**
 * Write a description of class Test here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Test
{
    

   
    public static void main(String args[])
    {
        Game t=new Game();
        t.play();
    }
}
